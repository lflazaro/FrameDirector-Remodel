.. libmypaint documentation master file, created by
   sphinx-quickstart2 on Wed Jun 13 23:40:45 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to libmypaint's documentation!
======================================

Contents:

.. toctree::
   :maxdepth: 2

libmypaint API reference
========================

.. doxygenindex::


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

