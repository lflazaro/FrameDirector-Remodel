#ifndef MYPAINT_H
#define MYPAINT_H

void mypaint_init(void);

#endif // MYPAINT_H
