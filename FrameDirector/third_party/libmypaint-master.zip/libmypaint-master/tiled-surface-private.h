

void render_dab_mask (uint16_t * mask,
                        float x, float y,
                        float radius,
                        float hardness,
                        float softness,
                        float aspect_ratio, float angle
                        );
